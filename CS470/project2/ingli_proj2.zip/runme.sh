#!/bin/bash
./tcpsim.sh 8.8.8.8 101.110.40.225 88.208.228.34 185.203.224.102
#               US,     Japan,         UK,           Spain