#ifndef DELAY
#define DELAY

void delay1us(uint16_t n);
void delay1ms(uint16_t n);

#endif